# ViralCut AI — Render deployment

## GitHub
Upload the contents of this folder (not the ZIP itself) to the root of your public GitHub repository and commit to `main`.

## Render
1. Open https://dashboard.render.com/
2. Click **New + → Web Service**.
3. Connect GitHub and select `golamrobbani90/viralc-ai`.
4. Select branch `main`.
5. Runtime should be detected as **Docker** because this package includes a Dockerfile.
6. Choose **Free** and click **Deploy Web Service**.
7. Wait for the deploy to finish. Render will show the public `onrender.com` URL.

Do not enter the Python build/start commands when using this Dockerfile; Docker builds the image and starts Gunicorn.

## Important
- This is an early prototype, not hardened for unrestricted public use.
- Render free instances can sleep and restart. Generated clips are stored on temporary local disk and may disappear.
- Video downloading/transcoding and Whisper may exceed free CPU/RAM limits or request timeouts.
- ffmpeg is installed in the Docker image. Whisper's model is downloaded on first transcription and may take time.
- Some social video sites block downloads or require authentication. Use only videos you own or are licensed to process.
- Viral selection is heuristic, not a guarantee.
