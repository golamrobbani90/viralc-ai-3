const $=id=>document.getElementById(id);
let poller=null;
$("paste").addEventListener("click",async()=>{try{$("url").value=await navigator.clipboard.readText()}catch(e){$("url").focus()}});
$("create").addEventListener("click",async()=>{
 const url=$("url").value.trim();
 if(!url){alert("আগে ভিডিও লিংক পেস্ট করো।");return}
 $("create").disabled=true;$("results").classList.add("hidden");$("status").classList.remove("hidden");
 $("statusText").textContent="কাজ শুরু হচ্ছে";$("detail").textContent="ভিডিও URL যাচাই করা হচ্ছে...";$("percent").textContent="0%";$("bar").style.width="0%";
 try{
  const res=await fetch("/api/create",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url,count:$("count").value,length:$("length").value})});
  const data=await res.json();if(!res.ok)throw new Error(data.error||"Request failed");
  poller=setInterval(()=>check(data.job_id),2500);
 }catch(e){$("detail").textContent=e.message;$("create").disabled=false}
});
async function check(id){
 try{
  const r=await fetch("/api/status/"+id);const d=await r.json();if(!r.ok)throw new Error(d.error);
  const names={queued:"Queue",downloading:"ভিডিও ডাউনলোড হচ্ছে",analyzing:"AI ভিডিও বিশ্লেষণ করছে",rendering:"ক্লিপ রেন্ডার হচ্ছে",done:"সম্পন্ন",error:"সমস্যা হয়েছে"};
  $("statusText").textContent=names[d.status]||d.status;
  $("percent").textContent=(d.progress||0)+"%";$("bar").style.width=(d.progress||0)+"%";
  $("detail").textContent=d.status==="downloading"?"ভিডিও সোর্স থেকে ফাইল আনা হচ্ছে।":d.status==="analyzing"?"কথা শনাক্ত করে সম্ভাব্য হাইলাইট বাছাই করা হচ্ছে।":d.status==="rendering"?"Vertical crop ও subtitles তৈরি হচ্ছে।":d.status==="done"?(d.transcribed?"Speech detected: "+d.language:"Speech transcription unavailable; fallback clips created."):(d.error||"অনুগ্রহ করে অপেক্ষা করো।");
  if(d.status==="done"){clearInterval(poller);$("create").disabled=false;$("results").classList.remove("hidden");$("clipList").innerHTML=d.clips.map((c,i)=>`<div class="clip"><div><strong>${i+1}. ${escapeHtml(c.title)}</strong><small>${c.duration}s · 1080 × 1920 · MP4</small></div><a href="/download/${id}/${encodeURIComponent(c.name)}">↓ Download</a></div>`).join("");}
  if(d.status==="error"){clearInterval(poller);$("create").disabled=false}
 }catch(e){clearInterval(poller);$("detail").textContent=e.message;$("create").disabled=false}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
