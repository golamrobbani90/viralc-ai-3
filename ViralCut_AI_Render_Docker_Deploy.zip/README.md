# ViralCut AI — starter website

A runnable local prototype that accepts a public video URL, downloads it with yt-dlp, transcribes speech with faster-whisper when available, ranks candidate moments using simple hook/engagement heuristics, then renders vertical 9:16 MP4 clips with burned-in subtitles.

## Requirements
- Python 3.10+
- FFmpeg + FFprobe installed and available on PATH
- Internet access to fetch permitted public videos
- For speech-to-text: `faster-whisper` downloads a model on first run (default `small`). Set `WHISPER_MODEL=tiny` for a lighter model.

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Notes / current limitations
- This is a starter app, not a hosted production service. It runs on your own computer.
- yt-dlp supports many sites, but no tool can guarantee every social platform URL will work. Some platforms require login, block downloads, or prohibit automated access.
- Only use videos you own or have permission to download and edit. Respect each platform's terms, copyright, and privacy rules.
- The “viral” ranking is heuristic, not a prediction or guarantee of virality.
- Captions are transcribed in the spoken language. Automatic translation between Bangla and English is not included yet.
- Face-aware reframing, speaker diarization, cloud queueing, authentication, storage cleanup, billing, and deployment are not included.
- For public deployment, add authentication, rate limits, per-user quotas, secure job storage, background workers, HTTPS, and strict URL/egress controls. Do not expose this development server directly to the internet.
