import os, re, uuid, threading, subprocess, json, ipaddress, socket
from pathlib import Path
from urllib.parse import urlparse
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename

ROOT = Path(__file__).parent.resolve()
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
JOBS = {}
LOCK = threading.Lock()
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024

def safe_url(value):
    p = urlparse(value.strip())
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("একটি বৈধ http/https ভিডিও URL দিন।")
    host = p.hostname.lower()
    if host in ("localhost",) or host.endswith(".local"):
        raise ValueError("লোকাল নেটওয়ার্কের URL গ্রহণ করা যাবে না।")
    try:
        infos = socket.getaddrinfo(host, None)
        for info in infos:
            ip = ipaddress.ip_address(info[4][0])
            if not ip.is_global:
                raise ValueError("প্রাইভেট বা লোকাল নেটওয়ার্কের URL গ্রহণ করা যাবে না।")
    except socket.gaierror:
        raise ValueError("URL-এর ডোমেইন খুঁজে পাওয়া যায়নি।")
    return value.strip()

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or "প্রসেসিং ব্যর্থ হয়েছে")[-1800:])
    return p.stdout

def probe_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(out.strip())

def transcribe(video, workdir):
    try:
        from faster_whisper import WhisperModel
        model_name = os.getenv("WHISPER_MODEL", "small")
        model = WhisperModel(model_name, device="cpu", compute_type="int8")
        audio = workdir / "audio.wav"
        run(["ffmpeg", "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000", str(audio)])
        segments, info = model.transcribe(str(audio), beam_size=3, vad_filter=True)
        result = []
        for s in segments:
            txt = (s.text or "").strip()
            if txt:
                result.append({"start": float(s.start), "end": float(s.end), "text": txt})
        return result, info.language or "unknown"
    except Exception:
        return [], "unknown"

def choose_clips(segments, duration, count=6, clip_len=35):
    if not segments:
        # No transcription model: evenly spaced useful preview clips.
        n = min(count, max(1, int(duration // 20)))
        if n == 1:
            return [{"start": max(0, (duration-clip_len)/2), "end": min(duration, clip_len), "title": "Highlight 1"}]
        starts = [max(0, (duration-clip_len) * i / (n-1)) for i in range(n)]
        return [{"start": s, "end": min(duration, s+clip_len), "title": f"Highlight {i+1}"} for i,s in enumerate(starts)]

    candidates = []
    for i, seg in enumerate(segments):
        start = max(0, seg["start"] - 5)
        end = min(duration, max(seg["end"] + 12, start + 18))
        if end-start < 12:
            continue
        window = [x for x in segments if x["start"] < end and x["end"] > start]
        text = " ".join(x["text"] for x in window)
        words = re.findall(r"\w+", text.lower())
        # Heuristic, not a guarantee of virality: hooks, questions, emotion, and concise speech.
        hooks = ["কিন্তু","কেন","কীভাবে","অবিশ্বাস্য","সত্যি","ভুল","জিত","হার","কারণ",
                 "but","why","how","secret","shocking","never","best","worst","because",
                 "amazing","mistake","truth","really","imagine","listen"]
        score = min(len(words), 110) / 18 + sum(1.7 for h in hooks if h in text.lower())
        score += 1.5 if "?" in text or "!" in text else 0
        score += 1.0 if 18 <= end-start <= 48 else 0
        candidates.append((score, start, end, text))
    candidates.sort(reverse=True)
    selected = []
    for score, start, end, text in candidates:
        if all(abs(start-x["start"]) > 18 for x in selected):
            selected.append({"start": start, "end": end, "title": " ".join(text.split())[:62] or "AI Highlight"})
        if len(selected) >= count:
            break
    selected.sort(key=lambda x: x["start"])
    return selected or choose_clips([], duration, count)

def make_ass(segments, start, end, outpath):
    header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,58,&H00FFFFFF,&H0000FFFF,&H00101010,&H80000000,1,0,0,0,100,100,0,0,1,4,1,2,70,70,145,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    def ts(sec):
        h=int(sec//3600); m=int((sec%3600)//60); s=sec%60
        return f"{h}:{m:02d}:{s:05.2f}"
    lines=[]
    for seg in segments:
        a=max(start, seg["start"]); b=min(end, seg["end"])
        if b<=a: continue
        txt=seg["text"].replace("{","(").replace("}",")").replace("\n"," ")
        lines.append(f"Dialogue: 0,{ts(a-start)},{ts(b-start)},Default,,0,0,0,,{txt}")
    outpath.write_text(header+"\n".join(lines), encoding="utf-8")

def make_clip(video, segs, clip, outpath, index):
    start, end = clip["start"], clip["end"]
    ass = outpath.with_suffix(".ass")
    make_ass(segs, start, end, ass)
    # Fill 9:16 canvas with a center crop; subtitle file is burned in.
    ass_path = str(ass).replace("\\", "/").replace(":", r"\:")
    vf = f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,subtitles='{ass_path}'"
    run(["ffmpeg", "-y", "-ss", f"{start:.2f}", "-i", str(video), "-t", f"{end-start:.2f}",
         "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
         "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(outpath)])
    return {"name": outpath.name, "title": clip["title"], "duration": round(end-start,1)}

def worker(job_id, url, count, length):
    folder = DATA / job_id
    folder.mkdir(parents=True, exist_ok=True)
    try:
        with LOCK: JOBS[job_id]["status"] = "downloading"
        try:
            import yt_dlp
        except ImportError:
            raise RuntimeError("yt-dlp ইনস্টল নেই। README অনুসরণ করে dependencies ইনস্টল করুন।")
        source = folder / "source.mp4"
        opts = {"format":"bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
                "outtmpl":str(source), "merge_output_format":"mp4", "noplaylist":True,
                "quiet":True, "no_warnings":True, "max_filesize":1024*1024*1024}
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
        if not source.exists():
            matches = list(folder.glob("source.*"))
            if not matches: raise RuntimeError("ভিডিও ফাইল পাওয়া যায়নি।")
            source = matches[0]
        duration = probe_duration(source)
        if duration < 10: raise RuntimeError("ভিডিওটি খুব ছোট (কমপক্ষে ১০ সেকেন্ড প্রয়োজন)।")
        with LOCK: JOBS[job_id]["status"] = "analyzing"
        segments, lang = transcribe(source, folder)
        clips = choose_clips(segments, duration, count, length)
        with LOCK:
            JOBS[job_id]["status"] = "rendering"
            JOBS[job_id]["language"] = lang
            JOBS[job_id]["transcribed"] = bool(segments)
        results=[]
        for i, clip in enumerate(clips, 1):
            out = folder / f"viral_clip_{i:02d}.mp4"
            results.append(make_clip(source, segments, clip, out, i))
            with LOCK: JOBS[job_id]["progress"] = int(i/len(clips)*100)
        with LOCK:
            JOBS[job_id].update(status="done", clips=results, progress=100)
    except Exception as e:
        with LOCK: JOBS[job_id].update(status="error", error=str(e))

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/create")
def create():
    data=request.get_json(silent=True) or {}
    try:
        url=safe_url(data.get("url",""))
        count=max(1,min(10,int(data.get("count",6))))
        length=max(15,min(60,int(data.get("length",35))))
    except Exception as e:
        return jsonify(error=str(e)),400
    job_id=uuid.uuid4().hex[:12]
    with LOCK:
        JOBS[job_id]={"status":"queued","progress":0,"clips":[]}
    threading.Thread(target=worker,args=(job_id,url,count,length),daemon=True).start()
    return jsonify(job_id=job_id)

@app.get("/api/status/<job_id>")
def status(job_id):
    with LOCK:
        item=JOBS.get(job_id)
        if not item: return jsonify(error="Job পাওয়া যায়নি"),404
        return jsonify(item)

@app.get("/download/<job_id>/<path:filename>")
def download(job_id, filename):
    folder=(DATA/job_id).resolve()
    target=(folder/filename).resolve()
    if folder not in target.parents or not target.is_file(): return "Not found",404
    return send_from_directory(folder, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
